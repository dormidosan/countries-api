-Create a AWS EBS with PHP ^8.1.x and a MySQL ^8.x database attached
-Upload zip file

https://github.com/dormidosan/countries-api