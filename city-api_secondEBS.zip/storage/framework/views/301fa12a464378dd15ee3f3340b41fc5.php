<!-- partial -->
<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
    <!-- p class="text-muted mb-1 mb-md-0"><a href="#" target="_blank">UI</a>.</p -->
    <p class="text-muted">WEB 2.0</p>
</footer>
<?php /**PATH C:\xampp\htdocs\city-api\resources\views/dashboard/partials/footer.blade.php ENDPATH**/ ?>