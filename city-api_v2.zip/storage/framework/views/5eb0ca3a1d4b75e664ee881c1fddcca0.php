<!-- resources/views/products/edit.blade.php -->



<?php $__env->startSection('main'); ?>
    <div class="page-content">

        <nav class="page-breadcrumb">
    <div class="container">
        <h2>Edit Product</h2>
        <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($product->name); ?>" required>
            </div>
            <div class="form-group">
                <label for="code">Code:</label>
                <input type="text" name="code" class="form-control" value="<?php echo e($product->code); ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea name="description" class="form-control"><?php echo e($product->description); ?></textarea>
            </div>
            <div class="form-group">
                <label for="image_url">Image URL:</label>
                <input type="text" name="image_url" class="form-control" value="<?php echo e($product->image_url); ?>">
            </div>
            <div class="form-group">
                <label for="category">Category:</label>
                <input type="text" name="category" class="form-control" value="<?php echo e($product->category); ?>" required>
            </div>
            <div class="form-group">
                <label for="manufacturer">Manufacturer:</label>
                <input type="text" name="manufacturer" class="form-control" value="<?php echo e($product->manufacturer); ?>" required>
            </div>
            <div class="form-group">
                <label for="area">Area:</label>
                <input type="text" name="area" class="form-control" value="<?php echo e($product->area); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
        </nav>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\city-api\resources\views/products/edit.blade.php ENDPATH**/ ?>