<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Responsive HTML Admin Dashboard Template based on Bootstrap 5">
    <meta name="author" content="NobleUI">
    <meta name="keywords"
          content="nobleui, bootstrap, bootstrap 5, bootstrap5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <title>Management</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <!-- End fonts -->

    <!-- core:css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/core/core.css')); ?>">
    <!-- endinject -->
    <link href="<?php echo e(asset('assets/vendors/select2/select2.min.css')); ?>" rel="stylesheet" />

    <!-- Plugin css for this page -->
    <!--link rel="stylesheet" href="{-{ asset('assets/vendors/flatpickr/flatpickr.min.css') }}" -->
    <!-- End plugin css for this page -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/mdi/css/materialdesignicons.min.css')); ?>">

    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/feather-font/css/iconfont.css')); ?>">
    <!-- link rel="stylesheet" href="{-{ asset('assets/vendors/flag-icon-css/css/flag-icon.min.css') }}" -->
    <!-- endinject -->

    <!-- Layout styles -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/demo2/style.css')); ?>">
    <!-- End layout styles -->


    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon96.png')); ?>"/>


    <?php echo $__env->yieldContent('custom-css'); ?>
</head>
<body>
<div class="main-wrapper">

    <!-- partial:partials/_sidebar.html -->
    <?php echo $__env->make('dashboard.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- start settings sidebar -->
    <!-- @-include('dashboard.partials.settings-sidebar')   -->

    <div class="page-wrapper">

        <!-- partial:partials/_navbar.html -->
        <?php echo $__env->make('dashboard.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- content for each page -->
        <?php echo $__env->yieldContent('main'); ?>

        <!-- partial:partials/_footer.html -->
        <?php echo $__env->make('dashboard.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>


</div>

<!-- core:js -->
<!-- script src="{-{ asset('assets/vendors/core/core.js')}}"></script -->
<script src="<?php echo e(asset('assets/jquery360.min.js')); ?>"></script>
<!-- endinject -->

<!-- Plugin js for this page -->
<!-- script src="{-{ asset('assets/vendors/flatpickr/flatpickr.min.js')}}"></script -->
<!-- script src="{-{ asset('assets/vendors/apexcharts/apexcharts.min.js')}}"></script -->
<!-- End plugin js for this page -->

<!-- inject:js -->
<script src="<?php echo e(asset('assets/vendors/feather-icons/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/template.js')); ?>"></script>
<!-- endinject -->

<!-- Custom js for this page -->
<!-- script src="{-{ asset('assets/js/dashboard-dark.js')}}"></script -->
<!-- End custom js for this page -->
<?php echo $__env->yieldContent('libraries'); ?>
<script>
    $(function() {
        console.log('script dashboard');


        //Error in jquery 3.6.0 preventing autofocus on select2
        //Work around
        $(document).on('select2:open', () => {
            document.querySelector('.select2-search__field').focus();
        });
    });

</script>
<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\city-api\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>