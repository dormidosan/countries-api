<div class="row g-0">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 col-md-6 col-lg-4">
            <div class="border-light-subtle clean-product-item">
                <div class="image"><a href="#"><img class="img-fluid d-block mx-auto" src="<?php echo e(asset($product->image_url)); ?>"></a></div>
                <div class="product-name"><a href="#"><?php echo e($product->name); ?></a></div>
                <div class="about">
                    <div class="rating"><img src="assetsfront/img/star.svg"><img src="assetsfront/img/star.svg"><img src="assetsfront/img/star.svg"><img src="assetsfront/img/star-half-empty.svg"><img src="assetsfront/img/star-empty.svg"></div>
                    <div class="price">
                        <h3><a href="<?php echo e(route('products.show', $product->id)); ?>"><?php echo e($product->id); ?></a></h3>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\city-api\resources\views/catalog/products.blade.php ENDPATH**/ ?>