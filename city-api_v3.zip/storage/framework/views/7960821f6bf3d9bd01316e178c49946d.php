<!-- resources/views/products/show.blade.php -->



<?php $__env->startSection('main'); ?>
    <div class="page-content">

        <nav class="page-breadcrumb">
            <div class="container">
                <h2>Product Details</h2>
                <p><strong>Name:</strong> <?php echo e($product->name); ?></p>
                <p><strong>Code:</strong> <?php echo e($product->code); ?></p>
                <p><strong>Description:</strong> <?php echo e($product->description); ?></p>
                <p><strong>Image URL:</strong> <?php echo e($product->image_url); ?></p>
                <p><strong>Category:</strong> <?php echo e($product->category); ?></p>
                <p><strong>Manufacturer:</strong> <?php echo e($product->manufacturer); ?></p>
                <p><strong>Area:</strong> <?php echo e($product->area); ?></p>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">Back</a>
            </div>
        </nav>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\city-api\resources\views/products/show.blade.php ENDPATH**/ ?>