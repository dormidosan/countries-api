<?php $__currentLoopData = $product->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="reviews">
        <div class="review-item">
            <div class="rating">
                <img src="assetsfront/img/star.svg">
                <img src="assetsfront/img/star.svg">
                <img src="assetsfront/img/star.svg">
                <img src="assetsfront/img/star.svg">
                <img src="assetsfront/img/star-empty.svg">
            </div>
            <h4 class="analysis"></h4>
            <span class="text-muted">
                <?php echo e($comment->created_at->diffForHumans()); ?>

            </span>
            <p>
                <?php echo e($comment->text); ?>

            </p>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="container">
    <h2>Add Comment</h2>
    <form action="<?php echo e(route('comments.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="text">Comment:</label>
            <textarea name="text" class="form-control" rows="3" required></textarea>
        </div>
        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Function to analyze sentiment
        async function analyzeSentiment(text) {
            try {
                const response = await fetch('https://ap8i28dv72.execute-api.us-east-1.amazonaws.com/BlogoSphere/sentiment_analysis', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ text })
                });

                if (response.ok) {
                    const responseData = await response.json();
                    return responseData; // Return the sentiment analysis result
                } else {
                    console.error('Unexpected HTTP status:', response.status, response.statusText);
                    return null;
                }
            } catch (error) {
                console.error('Error:', error.message);
                return null;
            }
        }

        // Loop through each review item and analyze sentiment
        document.querySelectorAll('.review-item').forEach(async function(reviewItem) {
            console.log("testing")
            const commentText = reviewItem.querySelector('p').textContent.trim();
            const analysisElement = reviewItem.querySelector('.analysis');

            const analysisResult = await analyzeSentiment(commentText);

            if (analysisResult) {
                analysisElement.textContent = `Sentiment: ${analysisResult.sentiment}, Confidence: ${analysisResult.confidence}`;
            } else {
                analysisElement.textContent = 'Failed to analyze sentiment';
            }
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\city-api\resources\views/product/comments.blade.php ENDPATH**/ ?>